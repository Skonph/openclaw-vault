# IBKR Options Autotrader — Project Context & Handoff

> **Purpose of this file.** Drop this into a new Cowork/Claude chat to continue the
> project. It captures what's built, where it runs, the conventions/gotchas, and a
> prioritized improvement backlog mapped to specific files. A fresh agent should be
> able to read this and keep improving the system without re-deriving everything.
>
> **Current version:** v13 · **Tests:** 142 passed.
> **Phase:** LIVE-PAPER (Options Level 4 approved, cutover completed, executing credit/IC/debit spreads on IBKR paper account DUQ548647).
> **Last updated:** 2026-06-13 (BKK)


---

## 1. Mission & honest guardrails (read first)

The system is an **autonomous options strategist + risk guardrail** for US index
ETF options (SPY/QQQ/IWM), running paper-first on IBKR.

It does **NOT** promise an 80% win rate or 20% returns — that target is unattainable
and any change request implying it should be pushed back on. What it actually targets:
**bounded, defined risk per trade + honest measurement of edge.** Discipline (declining
on no-edge days) is a feature, not a bug. Keep this framing in all future work.

Hard invariants that must never be weakened:
- **Defined-risk only.** Naked/undefined-risk structures are always rejected.
- **2% max loss per trade, −5% daily / −10% weekly kill-switch** (MODERATE policy).
- **Paper-account gate:** the IBKR executor refuses any account not starting `DU`/`DF`.
- **Permission-aware:** the guardrail only allows structures IBKR has approved
  (`OPTIONS_LEVEL` env; set to 3 = allows credit spreads, Iron Condors, etc., thanks to account upgrade to Level 4).

---

## 2. Architecture & data flow

```
Evening (08:15 UTC / 15:15 ICT)              Pre-session (08:30 UTC / 15:30 ICT)
  context_builder.py                           shadow_report.py
   ├─ Tradier quotes + ATM IV                    ├─ parse strategist_output.json
   ├─ Tradier daily history -> trend signals     ├─ guardrail-evaluate each plan
   ├─ econ calendar (manual FOMC -> FRED)         ├─ open shadow positions (tracker)
   └─ writes data/context.json                    └─ Telegram: would-trade + record
  strategist_run.py
   └─ OpenRouter (Haiku 4.5) -> data/strategist_output.json

Morning (01:30 UTC / 08:30 ICT)              [WHEN EXECUTION IS LIVE]
  daily_report.py                              run_ops_session.py (session timer)
   ├─ mark+close shadow positions (BS)           ├─ open approved plans on IBKR paper
   └─ Telegram: recap + shadow track record      ├─ exit monitor until flat
                                                 ├─ exit_monitor marked-equity check
                                                 flatten_all.py (before close)
                                                 daily_report.py (real trade recap)
```

Core pipeline (broker-agnostic): **strategist → strategist_bridge → guardrail →
(executor) → exit_monitor**. The backtest harness and shadow tracker reuse the same
guardrail + exit rules, so what's measured equals what would trade.

---

## 3. Repository layout (`options_guardrail/`)

**Risk & contract core**
- `risk_policy.py` — MODERATE limits; `OPTIONS_LEVEL` gates allowed structures
  (LEVEL2_STRUCTURES = long/debit only; LEVEL3 = +credit/condor/calendar). `ACTIVE_POLICY`.
- `schema.py` — `TradePlan`/`OptionLeg`/`Invalidation` contract + `from_dict` parser.
- `guardrail.py` — `Guardrail.evaluate(plan, state) -> GuardrailResult` (kill-switch,
  structure check, defined-risk, invalidation, sizing to 2% cap, portfolio caps).
- `state.py` — `AccountState` (equity, day/week anchors, drawdown, JSON persistence).
- `positions.py` — open-position model + JSON store.

**Execution & exits**
- `ibkr_paper_executor.py` — thin IBKR adapter (ib_async). Paper-gated. `execute`/`close_position`.
- `market_data.py` — `MarketDataProvider` protocol; `MockMarketData`; `IBKRMarketData`; `YahooMarketData` (REST quotes from Yahoo Finance); `FallbackMarketData` (chains Tradier ➡️ IBKR ➡️ Yahoo).
- `exit_monitor.py` — closes on invalidation / stop (85% max loss) / target; books P&L into state.

- `pipeline.py` — `SessionOrchestrator` (open approved + run exit loop; notifier/approver hooks).
- `run_ops_session.py` — live-paper entrypoint (config → Telegram → IBKR → orchestrator, file lock).
- `flatten_all.py` — EOD safety net: force-close everything before US close.

**Strategist & data feeds**
- `strategist_prompt.md` — the Opus/Haiku system prompt (emits TradePlan JSON; reads
  regime from `daily_signals`; honors ALLOWED STRUCTURES injected at runtime).
- `strategist_run.py` — builds prompt+context, calls model (OpenRouter or Anthropic),
  writes `strategist_output.json` (fail-safe to no_trade).
- `strategist_bridge.py` — tolerant JSON parse + `evaluate_envelope` through guardrail.
- `context_builder.py` — assembles `context.json` (account + Tradier flow/IV/trend + econ).
- `tradier_feed.py` — Tradier quotes, ATM IV, market clock, **daily history → trend signals**
  (momentum 5/10d, %vs SMA20, ATR, trend label). Self-check CLI. DATA-ONLY (never trades).
- `econ_calendar.py` — economic calendar: **Manual (data/manual_calendar.json) → Finnhub →
  FRED** fallback. Manual is per-date authoritative. Self-check CLI.

**Reporting & tracking**
- `telegram_notify.py` — notify + (semi-mode) approve. Markdown→plaintext fallback. NullTelegram.
- `shadow_report.py` — interim "would-trade" digest; opens shadow positions.
- `daily_report.py` — recap; marks+closes shadow positions; shows shadow track record.
- `shadow_tracker.py` — **shadow-performance tracker**: open plans, mark daily via BS,
  close on same exit rules, running hypothetical P&L (`data/shadow_ledger.json`).
- `preflight.py` — connectivity check (Tradier + OpenRouter + Telegram) → Telegram.

**Backtest**
- `bs.py` — Black-Scholes pricer. `backtest_data.py` — BS combo marking. `strategy.py` —
  default momentum strategy. `backtest.py` — engine + metrics (win rate, expectancy, PF,
  max DD). `backtest_run.py` — report writer.

**Ops & config**
- `config.py` — env-driven config (model provider, Telegram, IBKR, Tradier, econ keys,
  OPTIONS_LEVEL, equity from STARTING_CAPITAL, data_dir).
- `run.sh` — cron/systemd wrapper: sources `.env` (bash, strips inline comments) then runs
  a script in the venv. **All systemd services use this** (avoids EnvironmentFile pitfalls).
- `deploy.sh` — venv + deps + `pytest` + readiness summary.
- `.env.example` — template (copy to `.env`, chmod 600).
- `ops/` — systemd units + timers, `ibc-setup.md` (IB Gateway+IBC headless), `crontab.txt`,
  `RUNBOOK.md` (operator guide; has a "Kill it now" section).
- `manual_calendar.example.json`, `manual_calendar.2026_fomc.json` — econ-calendar seeds.
- `test_*.py` — 142 tests across all components (including `test_fallback_market_data.py`, `test_guardrail.py`, and `test_ibkr_paper_executor.py`).
- `HERMES.md` — Briefing and backlog for peer agent collaboration (e.g. hermes).

---

## 4. Deployment topology (the live server)

- **Host:** `ubuntu@43.160.222.7` (Tencent Cloud, **timezone ICT/UTC+7**).
- **Install dir:** `/home/ubuntu/guardrail` (NOT `/opt` — that vanished once; home is durable).
- **Secrets:** `/home/ubuntu/guardrail/.env` (chmod 600). Data: `data/`. Logs: `logs/`.
- **Systemd units run as `User=ubuntu`** and use `run.sh` for ExecStart (and ExecStartPre
  for context build). Paths point at `/home/ubuntu/guardrail`.
- **Timers are pinned to UTC** (`OnCalendar=... UTC`) so ICT system clock doesn't shift them.
- **Headless IB Gateway:** Configured via `ibc-gateway.service` running `/opt/ibc/scripts/ibcstart.sh` in the foreground under `xvfb-run` using bundled Zulu OpenJDK 17. Port 7497 (paper).


**Timer schedule (UTC → ICT):**

| Unit | UTC | ICT | Status |
|---|---|---|---|
| guardrail-strategist (context+strategist) | 08:30 & 14:10 Mon-Fri | 15:30 & 21:10 | **ENABLED (Twice Daily)** |
| guardrail-shadow (shadow report) | 08:45 & 14:15 Mon-Fri | 15:45 & 21:15 | **ENABLED (Twice Daily)** |
| guardrail-report (recap + shadow track record) | 01:30 Tue-Sat | 08:30 | **ENABLED** |
| guardrail-session (live execution) | 14:15 Mon-Fri | 21:15 | **OFF (needs IBKR)** |
| guardrail-flatten (EOD flatten) | 19:50 Mon-Fri | 02:50+1 | **OFF (needs IBKR)** |

---

## 5. Services & credentials (in `.env`)

- **Model:** OpenRouter (`OPENROUTER_API_KEY`), `STRATEGIST_MODEL=anthropic/claude-haiku-4.5`.
  (Provider auto-detects OpenRouter when its key is present.)
- **Telegram:** dedicated bot token, `TELEGRAM_CHAT_ID=8069530075`.
- **Tradier:** `TRADIER_ENV=prod`, `TRADIER_PROD_TOKEN` (real-time quotes/IV/history). DATA ONLY.
- **Econ calendar:** `FRED_API_KEY` (works, used), `FINNHUB_API_KEY` (calendar endpoint
  gated on free tier → falls back to FRED). Manual FOMC dates in `data/manual_calendar.json`.
- **IBKR:** account `U25439978` (live, options **Level 4** approved!). Paper account `DUQ548647`. `OPTIONS_LEVEL=3` set to enable credit/IC/debit spreads.
- **Equity basis:** `STARTING_CAPITAL` (or `GUARDRAIL_EQUITY`).

---

## 6. Operational status & daily cadence (what's happening now)

LIVE-PAPER phase — broker execution is live and autonomous on paper account `DUQ548647`:
- Nightly: context built from real Tradier data (incl. multi-day trend) + econ calendar;
  Haiku strategist produces Level-3 plans (credit spreads, Iron Condors, calendars, debit spreads).
- 15:30 ICT: shadow report to Telegram (would-trade plans, guardrail-sized) + opens shadow positions.
- 08:30 ICT: recap to Telegram + shadow track record (forward P&L of would-trades, marked via BS).

Known-good behaviors observed: strategist correctly reads SPY/QQQ/IWM uptrend and produces debit call spreads; correctly returns no_trade on directionless low-IV days.

---

## 7. Conventions & gotchas (hard-won — respect these)

1. **Deploy via full sync, preserve server edits.** Build a zip of the project, scp it,
   then `rsync -a --exclude 'ops/' ~/stage/options_guardrail/ ~/guardrail/`. This keeps all
   `.py`/tests in lockstep (avoids stale-test failures) while preserving the server's edited
   `ops/*.service|timer` and untouched `.env`/`data/`.
2. **systemd EnvironmentFile ≠ bash source.** systemd keeps inline `# comments` in values and broke `OPENROUTER_API_KEY`. Fix: **all services ExecStart go through `run.sh`**.
3. **Timezone:** server is ICT; timers are pinned with `... UTC`. Tests derive date keys from `datetime.now(timezone.utc)`.
4. **Telegram Markdown:** dynamic content breaks Telegram's Markdown parser. `telegram_notify.notify()` retries as plain text.
5. **`/opt` is not reliable on this box; use `/home/ubuntu/guardrail`.**
6. **Pre-open quotes look flat (0.00%).** Read the regime from `overnight_flow.daily_signals`, NOT the spot quote.
7. **Tradier prod token can trade the live account.** Never add an order method to `tradier_feed.py`.
8. **Shadow tracker marks once/day** (daily granularity).
9. **The IBKR adapter is paper-gated** (`DU`/`DF` only).
10. **Headless Java / systemd service gotcha:** Run `/opt/ibc/scripts/ibcstart.sh` directly in the foreground, using the bundled Zulu OpenJDK JRE instead of system's headless Java runtime.

---

## 8. Test & deploy workflow

```bash
# local edit → build zip → deploy on server
scp options_guardrail_vX.zip ubuntu@43.160.222.7:~/
ssh ubuntu@43.160.222.7
unzip -o ~/options_guardrail_vX.zip -d ~/stage
rsync -a --exclude 'ops/' ~/stage/options_guardrail/ ~/guardrail/ && rm -rf ~/stage
cd ~/guardrail && ./deploy.sh           # expect: 142 passed + readiness OK
```

---

## 9. Improvement backlog (prioritized; file → change)

**P0 — Execution cutover & Level 3 Expansion (Completed ✅)**
- Verified `managedAccounts()` returns `DUQ548647` and configured services (`guardrail-session`, `guardrail-flatten`, `guardrail-report`).
- Enabled credit/IC/calendar structures with `OPTIONS_LEVEL=3` set.
- Enforced `$0.50` premium floor + VIX-based 1-2 contract scaling (resolving fee-drag concerns).
- Replaced synthetic GBM paths with real historical bars in the backtester.

**P1 — Make live execution trustworthy (Completed ✅)**
- `market_data.py`: `IBKRMarketData.position_pnl` rewritten to per-leg valuation (qualify each leg, snapshot bid/ask/last/close, net against `entry_net_price`), with a stderr diagnostic cross-check against IBKR portfolio `unrealizedPNL`.
- `market_data.py`: `IBKRMarketData.implied_vol` now tries Tradier ATM IV first, falling back to IBKR generic tick 106 on the underlying.
- `ibkr_paper_executor.py`: `_get_combo_mid` prices combos at the bid/ask mid ("split the spread"). **v13 fix:** the mid calc previously required `bid > 0 and ask > 0`, which silently rejected the negative bid/ask that net-credit combos (credit spreads, Iron Condors) legitimately quote on the BAG — exactly the structures `OPTIONS_LEVEL=3` unlocked — and fell back to `plan.net_price`/MKT. Now only NaN and the `(0, 0)` "no data" sentinel are rejected; negative mids compute correctly. Covered by new tests `test_execute_uses_negative_mid_for_credit_combo`, `test_get_combo_mid_handles_negative_bid_ask_for_credit_combo`, `test_get_combo_mid_treats_zero_zero_as_no_data` (142 tests total).

**P2 — Risk completeness (marked-equity kill-switch) (Completed ✅)**
- Added `use_marked_drawdown=True` support to check both realized + unrealized P&L against daily/weekly anchors inside `guardrail.py` and `exit_monitor.py`. Configurable via `.env`.

**P3 — Tradier exit-test verification**
- `position_monitor.py` (Tradier): End-to-end exit test verification is the single highest-priority open item across all three systems. P&L reported by the bot must not be trusted until confirmed working.

**P4 — OpenClaw Intelligence Gap**
- `conviction_scorer.py` (OpenClaw): Enable `_score_anthropic()` by configuring `ANTHROPIC_API_KEY` in `.env` to resolve the offline-fallback intelligence gap.

**P5 — Server load / contention check**
- Check CPU/memory contention on the box during the 21:10–21:30 ICT window now that IBKR's live `guardrail-session` overlaps Tradier's scan and OpenClaw's Hermes resolver window.

**P6 — Reporting polish**
- `shadow_tracker.py`/reports: show **unrealized** P&L of OPEN shadow positions (currently only realized in the summary).

---

## 10. How a new chat should continue

1. **Treat this repo as the source of truth.** The code lives in `options_guardrail/`; the live copy is `/home/ubuntu/guardrail` on the server.
2. **Always keep tests green** (`./deploy.sh` runs `pytest`). Add a test for any new behavior.
3. **Respect the invariants in §1 and the gotchas in §7.**
4. **Deploy via the full-sync method in §8** (zip → rsync `--exclude 'ops/'`), never cherry-pick.
5. **Pick from the backlog in §9**.
6. **Current immediate context:** Account upgraded to Options Level 4. Completed P0 execution cutover, contract-scaling, premium thresholds, and real history backtesting. Completed P2 marked-equity kill-switch. Live paper-trading is now active.
